# models/generator_funie.py
# Baseline generator: FUnIE-GAN style U-Net (no depthwise / no attention)
# 输入/输出范围：[-1, 1]，输出层使用 Tanh。

import torch
import torch.nn as nn


class ConvBlock(nn.Module):
    """Conv2d -> BatchNorm -> LeakyReLU (or ReLU)
    down=True: 使用步长2的卷积做下采样
    """
    def __init__(self, in_c, out_c, down=True, use_bn=True, act='lrelu'):
        super().__init__()
        if down:
            # 下采样：k4 s2 p1（保持尺寸减半）
            layers = [nn.Conv2d(in_c, out_c, kernel_size=4, stride=2, padding=1, bias=not use_bn)]
        else:
            # 普通卷积：k3 s1 p1（保持尺寸不变）
            layers = [nn.Conv2d(in_c, out_c, kernel_size=3, stride=1, padding=1, bias=not use_bn)]

        if use_bn:
            layers.append(nn.BatchNorm2d(out_c))

        if act == 'lrelu':
            layers.append(nn.LeakyReLU(0.2, inplace=True))
        elif act == 'relu':
            layers.append(nn.ReLU(inplace=True))

        self.block = nn.Sequential(*layers)

    def forward(self, x):
        return self.block(x)


class DeconvBlock(nn.Module):
    """ConvTranspose2d 上采样 -> BatchNorm -> ReLU"""
    def __init__(self, in_c, out_c, use_bn=True):
        super().__init__()
        layers = [nn.ConvTranspose2d(in_c, out_c, kernel_size=4, stride=2, padding=1, bias=not use_bn)]
        if use_bn:
            layers.append(nn.BatchNorm2d(out_c))
        layers.append(nn.ReLU(inplace=True))
        self.block = nn.Sequential(*layers)

    def forward(self, x):
        return self.block(x)


class GeneratorFUNIE(nn.Module):
    """
    FUnIE-GAN 基线：U-Net 编解码结构 + 跳连
    通道配置：64-128-256-512（下采样） → 反卷积上采样并与编码端拼接
    输出：3通道，Tanh 到 [-1,1]
    """
    def __init__(self, in_ch=3, out_ch=3, base_ch=64):
        super().__init__()

        # Encoder
        self.e1 = ConvBlock(in_ch,   base_ch,   down=True,  use_bn=False)  # 128x128
        self.e2 = ConvBlock(base_ch, base_ch*2, down=True,  use_bn=True)   # 64x64
        self.e3 = ConvBlock(base_ch*2, base_ch*4, down=True, use_bn=True)  # 32x32
        self.e4 = ConvBlock(base_ch*4, base_ch*8, down=True, use_bn=True)  # 16x16
        self.eb = ConvBlock(base_ch*8, base_ch*8, down=True, use_bn=True)  # 8x8 bottleneck

        # Decoder（上采样 + 跳连）
        self.d4 = DeconvBlock(base_ch*8, base_ch*8)        # 16x16
        self.d4_conv = ConvBlock(base_ch*8*2, base_ch*8, down=False, use_bn=True, act='relu')

        self.d3 = DeconvBlock(base_ch*8, base_ch*4)        # 32x32
        self.d3_conv = ConvBlock(base_ch*4*2, base_ch*4, down=False, use_bn=True, act='relu')

        self.d2 = DeconvBlock(base_ch*4, base_ch*2)        # 64x64
        self.d2_conv = ConvBlock(base_ch*2*2, base_ch*2, down=False, use_bn=True, act='relu')

        self.d1 = DeconvBlock(base_ch*2, base_ch)          # 128x128
        self.d1_conv = ConvBlock(base_ch*2, base_ch, down=False, use_bn=True, act='relu')

        # 输出到原分辨率（再上采样一次）
        self.out_up = DeconvBlock(base_ch, base_ch//2)     # 256x256
        self.out_conv = nn.Conv2d(base_ch//2, out_ch, kernel_size=3, stride=1, padding=1)
        self.tanh = nn.Tanh()

        self._init_weights()

    def _init_weights(self):
        for m in self.modules():
            if isinstance(m, (nn.Conv2d, nn.ConvTranspose2d)):
                nn.init.kaiming_normal_(m.weight, nonlinearity='relu')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, (nn.BatchNorm2d,)):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)

    def forward(self, x):
        # Encoder
        e1 = self.e1(x)
        e2 = self.e2(e1)
        e3 = self.e3(e2)
        e4 = self.e4(e3)
        eb = self.eb(e4)

        # Decoder + Skip
        d4 = self.d4(eb)
        d4 = self.d4_conv(torch.cat([d4, e4], dim=1))

        d3 = self.d3(d4)
        d3 = self.d3_conv(torch.cat([d3, e3], dim=1))

        d2 = self.d2(d3)
        d2 = self.d2_conv(torch.cat([d2, e2], dim=1))

        d1 = self.d1(d2)
        d1 = self.d1_conv(torch.cat([d1, e1], dim=1))

        out = self.out_up(d1)
        out = self.out_conv(out)
        return self.tanh(out)
