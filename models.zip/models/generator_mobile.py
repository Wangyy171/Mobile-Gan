import torch
import torch.nn as nn

class DWConvBlock(nn.Module):
    def __init__(self, in_ch, out_ch, stride=1):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_ch, in_ch, 3, stride=stride, padding=1, groups=in_ch, bias=False),
            nn.BatchNorm2d(in_ch), nn.ReLU(inplace=True),
            nn.Conv2d(in_ch, out_ch, 1, bias=False),
            nn.BatchNorm2d(out_ch), nn.ReLU(inplace=True)
        )
    def forward(self, x): return self.block(x)

class Encoder(nn.Module):
    def __init__(self, chs=(3,32,64,128,256)):
        super().__init__()
        self.blocks = nn.ModuleList([DWConvBlock(chs[i], chs[i+1]) for i in range(len(chs)-1)])
        self.pool = nn.MaxPool2d(2)
    def forward(self, x):
        feats = []
        for blk in self.blocks:
            x = blk(x)
            feats.append(x)
            x = self.pool(x)
        return feats  # e1,e2,e3,e4

class GeneratorMobile(nn.Module):
    def __init__(self):
        super().__init__()
        self.enc = Encoder()
        self.bot = DWConvBlock(256,256)
        self.up1 = nn.ConvTranspose2d(256,128,2,2)
        self.up2 = nn.ConvTranspose2d(128,64,2,2)
        self.up3 = nn.ConvTranspose2d(64,32,2,2)
        self.conv1 = DWConvBlock(128+128,128)
        self.conv2 = DWConvBlock(64+64,64)
        self.conv3 = DWConvBlock(32+32,32)
        self.outc = nn.Conv2d(32,3,1)
        self.tanh = nn.Tanh()
    def forward(self, x):
        e1,e2,e3,e4 = self.enc(x)
        b = self.bot(e4)
        x = self.up1(b); x = torch.cat([x, e3], 1); x = self.conv1(x)
        x = self.up2(x); x = torch.cat([x, e2], 1); x = self.conv2(x)
        x = self.up3(x); x = torch.cat([x, e1], 1); x = self.conv3(x)
        return self.tanh(self.outc(x))
