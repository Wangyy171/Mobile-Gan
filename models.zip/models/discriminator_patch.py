import torch.nn as nn

def Ck(ic, oc, s):
    return nn.Sequential(
        nn.Conv2d(ic, oc, 4, stride=s, padding=1),
        nn.InstanceNorm2d(oc, affine=True),
        nn.LeakyReLU(0.2, True)
    )

class DiscriminatorLite(nn.Module):
    def __init__(self, in_ch=3):
        super().__init__()
        self.net = nn.Sequential(
            Ck(in_ch, 32, 2),
            Ck(32, 64, 2),
            Ck(64, 128, 2),
            nn.Conv2d(128, 1, 3, padding=1)
        )
    def forward(self, x): return self.net(x)
